package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JTextArea;

public class DroolsTest {

	private JFrame frmSmartSecurityHome;
	private JTextField tempVred;
	private final ButtonGroup vodaGrupa = new ButtonGroup();
	private final ButtonGroup dimGrupa = new ButtonGroup();
	private JTextField tngVred;
	private JTextField coVred;
	private JTextField ch4Vred;
	private JTextField c3h8Vred;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	
	private double tempVrednost;
	private String vodaVrednost;
	private String dimVrednost;
	private String karticaVrednost;
	private String vrataVrednost;
	private String prozorVrednost;
	private double tngVrednost;
	private double coVrednost;
	private double ch4Vrednost;
	private double c3h8Vrednost;
		
		// Promenljiva koja sadr�i poruku preporucene akcije
		String poruka;
		
		
		// Setovanje poruke
		public void setPoruka(String poruka) {
			this.poruka = poruka;
		}
		
		
		// Getovanje poruke
		public String getPoruka() {
			return poruka;
		}
		
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DroolsTest window = new DroolsTest();
					window.frmSmartSecurityHome.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DroolsTest() {
		initialize(); 
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frmSmartSecurityHome = new JFrame();
		frmSmartSecurityHome.getContentPane().setBackground(Color.WHITE);
		frmSmartSecurityHome.setTitle("Smart Security Home");
		frmSmartSecurityHome.setBounds(100, 100, 500, 480);
		frmSmartSecurityHome.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSmartSecurityHome.getContentPane().setLayout(null);
		
		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();      
		int x=(int)((dimension.getWidth() - 450)/2);
		int y=(int)((dimension.getHeight() - 450)/2);
		frmSmartSecurityHome.setLocation(x, y); 
		
		tempVred = new JTextField();
		tempVred.setBounds(278, 39, 86, 20);
		frmSmartSecurityHome.getContentPane().add(tempVred);
		tempVred.setColumns(10);
		
		JRadioButton vodaIma = new JRadioButton("Ima");
		vodaGrupa.add(vodaIma);
		vodaIma.setBounds(268, 66, 59, 23);
		frmSmartSecurityHome.getContentPane().add(vodaIma);
		
		JRadioButton vodaNema = new JRadioButton("Nema");
		vodaGrupa.add(vodaNema);
		vodaNema.setBounds(349, 66, 84, 23);
		frmSmartSecurityHome.getContentPane().add(vodaNema);
		
		JRadioButton dimIma = new JRadioButton("Ima");
		dimGrupa.add(dimIma);
		dimIma.setBounds(268, 92, 59, 23);
		frmSmartSecurityHome.getContentPane().add(dimIma);
		
		JRadioButton dimNema = new JRadioButton("Nema");
		dimGrupa.add(dimNema);
		dimNema.setBounds(349, 92, 71, 23);
		frmSmartSecurityHome.getContentPane().add(dimNema);
		
		tngVred = new JTextField();
		tngVred.setBounds(278, 200, 86, 20);
		frmSmartSecurityHome.getContentPane().add(tngVred);
		tngVred.setColumns(10);
		
		coVred = new JTextField();
		coVred.setBounds(278, 224, 86, 20);
		frmSmartSecurityHome.getContentPane().add(coVred);
		coVred.setColumns(10);
		
		ch4Vred = new JTextField();
		ch4Vred.setBounds(278, 250, 86, 20);
		frmSmartSecurityHome.getContentPane().add(ch4Vred);
		ch4Vred.setColumns(10);
		
		c3h8Vred = new JTextField();
		c3h8Vred.setBounds(278, 274, 86, 20);
		frmSmartSecurityHome.getContentPane().add(c3h8Vred);
		c3h8Vred.setColumns(10);
		
		JRadioButton karticaValidna = new JRadioButton("Validna");
		buttonGroup.add(karticaValidna);
		karticaValidna.setBounds(268, 118, 71, 23);
		frmSmartSecurityHome.getContentPane().add(karticaValidna);
		
		JRadioButton karticaNijeValidna = new JRadioButton("Nije validna");
		buttonGroup.add(karticaNijeValidna);
		karticaNijeValidna.setBounds(349, 118, 98, 23);
		frmSmartSecurityHome.getContentPane().add(karticaNijeValidna);
		
		JRadioButton vrataOtvorena = new JRadioButton("Otvorena");
		buttonGroup_1.add(vrataOtvorena);
		vrataOtvorena.setBounds(268, 144, 84, 23);
		frmSmartSecurityHome.getContentPane().add(vrataOtvorena);
		
		JRadioButton vrataZatvorena = new JRadioButton("Zatvorena");
		buttonGroup_1.add(vrataZatvorena);
		vrataZatvorena.setBounds(349, 144, 98, 23);
		frmSmartSecurityHome.getContentPane().add(vrataZatvorena);
		
		JRadioButton prozorPolomljen = new JRadioButton("Polomljen");
		buttonGroup_2.add(prozorPolomljen);
		prozorPolomljen.setBounds(268, 170, 84, 23);
		frmSmartSecurityHome.getContentPane().add(prozorPolomljen);
		
		JRadioButton prozorNijePolomljen = new JRadioButton("Nije polomljen");
		buttonGroup_2.add(prozorNijePolomljen);
		prozorNijePolomljen.setBounds(349, 170, 109, 23);
		frmSmartSecurityHome.getContentPane().add(prozorNijePolomljen);
		
		JButton resenje = new JButton("Resenje");
		resenje.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				tempVrednost = Double.parseDouble(tempVred.getText());
				
				if(vodaIma.isSelected()) {
					vodaVrednost = "Ima";
				}else if(vodaNema.isSelected()) {
					vodaVrednost = "Nema";
				}
				
				if(dimIma.isSelected()) {
					dimVrednost = "Ima";
				}else if(dimNema.isSelected()) {
					dimVrednost = "Nema";
				}
				
				if(karticaValidna.isSelected()) {
					karticaVrednost = "Validna";
				}else if(karticaNijeValidna.isSelected()) {
					karticaVrednost = "Nije validna";
				}
				
				if(vrataOtvorena.isSelected()) {
					vrataVrednost = "Otvorena";
				}else if(vrataZatvorena.isSelected()) {
					vrataVrednost = "Zatvorena";
				}
				
				if(prozorNijePolomljen.isSelected()) {
					prozorVrednost = "Nije aktiviran";
				}else if(prozorPolomljen.isSelected()) {
					prozorVrednost = "Aktiviran";
				}
				
				tngVrednost = Double.parseDouble(tngVred.getText());
				coVrednost = Double.parseDouble(coVred.getText());
				ch4Vrednost = Double.parseDouble(ch4Vred.getText());
				c3h8Vrednost = Double.parseDouble(c3h8Vred.getText());
				
				
				try {
			        KieServices ks = KieServices.Factory.get();
		    	    KieContainer kContainer = ks.getKieClasspathContainer();
		        	KieSession kSession = kContainer.newKieSession("ksession-rules");
		        	
		        	// Objekat klase DroolsTest (test) - za set/get poruke
		        	DroolsTest test = new DroolsTest();
		        	
		        	
		        	// Instanciranje objekta klase Temp
		        	Temp t = new Temp();
		        	
		        	// Ocitavanje senzora (podataka)
		        	// Ulazni parametar je ocitavanje sa senzora temperature
		        	// Ulazni tip podatka/ocitavanja senzora je DOUBLE vrednost
		        	t.setSenzorTemp(tempVrednost);
		        	
		        	
		        	// Instanciranje objekta klase VodaDim i setovanje vrednosti
		        	VodaDim vd = new VodaDim();
		        	
		        	// Ocitavanje senzora (podataka)
		        	// Ulazni parametri su ocitavanja senzora za detekciju vode i dima
		        	// Ulazni tip podataka/ocitavanja senzora su STRING vrednosti
		        	// Senzor za detekciju vode: Ima - Nema
		        	vd.setSenzorVoda(vodaVrednost);
		        	// Senzor za detekciju dima: Ima - Nema
		        	vd.setSenzorDim(dimVrednost);
		        	
		        	
		        	// Instanciranje objekta klase VrataProzor i setovanje vrednosti
		        	VrataProzor vp = new VrataProzor();
		        	
		        	// Ocitavanje validnosti kartice i senzora (podataka) 
		        	// Ulazni parametri su ocitavanje validnosti kartice, senzora polo�aja vrata kao i senzor za detekciju lomljenja stakla
		        	// Ulazni tip podataka/ocitavanja su STRING vrednosti
		        	// Validnost kartice: Validna - Nije Validna
		        	vp.setCitacKartice(karticaVrednost);
		        	// Senzor polo�aja vrata: Otvorena - Zatvorena
		        	vp.setSenzorPolozajaVrata(vrataVrednost);
		        	// Senzor za detekciju lomljenja stakla: Aktiviran - Nije aktiviran
		        	vp.setSenzorProzora(prozorVrednost);
		        	
		        	
		        	// Instanciranje objekta klase Gas i setovanje vrednosti
		        	Gas g = new Gas();
		        	
		        	// Ocitavanje senzora (podataka)
		        	// Ulazni parametri su ocitavanja senzora za detekciju gasova
		        	// Ulazni tip podataka/ocitavanja je DOUBLE vrednost (procenat koncentracije/prisustva gasa)
		        	// Senzor za detekciju gasa - TNG (Tecni naftni gas)
		        	g.setSenzorTNG(tngVrednost);
		        	// Senzor za detekciju gasa - CO (Ugljen monoksid)
		        	g.setSenzorCO(coVrednost);
		        	// Senzor za detekciju gasa - CH4 (Metan)
		        	g.setSenzorCH4(ch4Vrednost);
		        	// Senzor za detekciju gasa - C3H8 (Propan)
		        	g.setSenzorC3H8(c3h8Vrednost);
		        	
		        	
		        	// Setovanje stanja ekspertskih sistema
		        	
		        	// Setovanje ES_1
		        	// Moguca stanja: Niska - Normalna - Visoka
		        	t.setES_1();
		        	
		        	// Setovanje ES_2
		        	// Moguca stanja: Ni�ta - Slu�ba
		        	vd.setES_2();
		        	
		        	// Setovanje ES_3
		        	// Moguca stanja: Ni�ta - Slu�ba - Security
		        	vp.setES_3();
		        	
		        	// Setovanje ES_4
		        	// Moguca stanja: Ni�ta - Provetri - Slu�ba
		        	g.setES_4();

		        	
		        	// Insertovanje objekata
		        	// Objekat klase Temp
		            kSession.insert(t);
		            // Objekat klase VodaDim
		            kSession.insert(vd);
		            // Objekat klase VrataProzor
		            kSession.insert(vp);
		            // Objekat klase Gas
		            kSession.insert(g);
		            // Objekat klase DroolsTest
		            kSession.insert(test);
		            
		            
		            // Inicijalizacija pravila
		            kSession.fireAllRules();
		            
		            JOptionPane.showMessageDialog(null, test.getPoruka());
		            
		            
		        } catch (Throwable t) {
		            t.printStackTrace();
		        }
			
				
				
			}});
		resenje.setBounds(197, 315, 89, 23);
		frmSmartSecurityHome.getContentPane().add(resenje);
		
		JTextPane textPane = new JTextPane();
		textPane.setText("%");
		textPane.setBounds(375, 200, 27, 20);
		frmSmartSecurityHome.getContentPane().add(textPane);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setText("%");
		textPane_1.setBounds(375, 224, 27, 20);
		frmSmartSecurityHome.getContentPane().add(textPane_1);
		
		JTextPane textPane_2 = new JTextPane();
		textPane_2.setText("%");
		textPane_2.setBounds(375, 250, 27, 20);
		frmSmartSecurityHome.getContentPane().add(textPane_2);
		
		JTextPane textPane_3 = new JTextPane();
		textPane_3.setText("%");
		textPane_3.setBounds(375, 274, 27, 20);
		frmSmartSecurityHome.getContentPane().add(textPane_3);
		
		JLabel lblNewLabel = new JLabel("Simulacija o\u010Ditavanja parametara");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(128, 11, 227, 20);
		frmSmartSecurityHome.getContentPane().add(lblNewLabel);
		
		JLabel lblOitavanjeTemperature = new JLabel("O\u010Ditavanje temperature");
		lblOitavanjeTemperature.setBounds(20, 45, 157, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeTemperature);
		
		JLabel lblOitavanjeSenzoraZa = new JLabel("O\u010Ditavanje senzora za detekciju vode");
		lblOitavanjeSenzoraZa.setBounds(20, 73, 242, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraZa);
		
		JLabel lblOitavanjeSenzoraZa_1 = new JLabel("O\u010Ditavanje senzora za detekciju dima");
		lblOitavanjeSenzoraZa_1.setBounds(20, 99, 242, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraZa_1);
		
		JLabel lblValidnostKartice = new JLabel("Validnost kartice");
		lblValidnostKartice.setBounds(20, 124, 119, 14);
		frmSmartSecurityHome.getContentPane().add(lblValidnostKartice);
		
		JLabel lblPoloajVrata = new JLabel("Polo\u017Eaj vrata");
		lblPoloajVrata.setBounds(20, 149, 109, 14);
		frmSmartSecurityHome.getContentPane().add(lblPoloajVrata);
		
		JLabel lblStanjeProzora = new JLabel("Stanje prozora");
		lblStanjeProzora.setBounds(20, 174, 109, 14);
		frmSmartSecurityHome.getContentPane().add(lblStanjeProzora);
		
		JLabel lblOitavanjeSenzoraTng = new JLabel("O\u010Ditavanje senzora TNG (Te\u010Dni naftni gas)");
		lblOitavanjeSenzoraTng.setBounds(20, 205, 256, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraTng);
		
		JLabel lblOitavanjeSenzoraCo = new JLabel("O\u010Ditavanje senzora CO (Ugljen-monoksid)");
		lblOitavanjeSenzoraCo.setBounds(20, 230, 256, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraCo);
		
		JLabel lblOitavanjeSenzoraCh = new JLabel("O\u010Ditavanje senzora CH4 (Metan)");
		lblOitavanjeSenzoraCh.setBounds(20, 256, 241, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraCh);
		
		JLabel lblOitavanjeSenzoraCh_1 = new JLabel("O\u010Ditavanje senzora C3H8 (Propan)");
		lblOitavanjeSenzoraCh_1.setBounds(20, 280, 256, 14);
		frmSmartSecurityHome.getContentPane().add(lblOitavanjeSenzoraCh_1);
		
		JLabel lblNewLabel_1 = new JLabel("\u00B0C");
		lblNewLabel_1.setBounds(370, 42, 32, 14);
		frmSmartSecurityHome.getContentPane().add(lblNewLabel_1);
		
		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmSmartSecurityHome.dispose();
			}
		});
		btnExit.setBounds(197, 401, 89, 23);
		frmSmartSecurityHome.getContentPane().add(btnExit);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(46, 356, 93, 20);
		frmSmartSecurityHome.getContentPane().add(textArea);
		
	}
}
