package com.sample;

public class Gas {
	
	// Promenljive unutar klase Gas
	private int senzorTNG;
	private int senzorCO;
	private int senzorCH4;
	private int senzorC3H8;
	private String ES_4;
	
	// Setovanje ocitavanja podataka sa senzora za detekciju gasa - TNG (Tecni naftni gas) u procentima (%)
	public void setSenzorTNG(double senzorTNG) {
		if(senzorTNG < 0.8) {
			this.senzorTNG = 0;
		}else if(senzorTNG >= 0.8 && senzorTNG <= 2.0) {
			this.senzorTNG = 1;
		}else {
			this.senzorTNG = 2;
		}
	}
	
	// Setovanje ocitavanja podataka sa senzora za detekciju gasa - CO (Ugljen monoksid) u procentima (%)
	public void setSenzorCO(double senzorCO) {
		if(senzorCO < 0.17) {
			this.senzorCO = 0;
		}else if(senzorCO >= 0.17 && senzorCO <= 0.64) {
			this.senzorCO = 1;
		}else {
			this.senzorCO = 2;
		}
	}
	
	// Setovanje ocitavanja podataka sa senzora za detekciju gasa - CH4 (Metan) u procentima (%)
	public void setSenzorCH4(double senzorCH4) {
		if(senzorCH4 < 1.5) {
			this.senzorCH4 = 0;
		}else if(senzorCH4 >= 1.5 && senzorCH4 <= 5.0) {
			this.senzorCH4 = 1;
		}else {
			this.senzorCH4 = 2;
		}
	}
	
	// Setovanje ocitavanja podataka sa senzora za detekciju gasa - C3H8 (Propan) u procentima (%)
	public void setSenzorC3H8(double senzorC3H8) {
		if(senzorC3H8 < 1.0) {
			this.senzorC3H8 = 0;
		}else if(senzorC3H8 >= 1.0 && senzorC3H8 <= 2.36) {
			this.senzorC3H8 = 1;
		}else {
			this.senzorC3H8 = 2;
		}
	}
	
	// Setovanje stanja ES_4
	public void setES_4() {
		if(senzorTNG == 0 && senzorCO == 0 && senzorCH4 == 0 && senzorC3H8 == 0) {
			ES_4 = "Ni�ta";
		}else if((senzorTNG == 1 || senzorTNG == 0) && (senzorCO == 1 || senzorCO == 0) && (senzorCH4 == 1 || senzorCH4 == 0) && (senzorC3H8 == 1 || senzorC3H8 ==0 )) {
			ES_4 = "Provetri";
		}else {
			ES_4 = "Slu�ba";
		}
		
	}
	
	// Getovanje stanja ES_4
	public String getES_4() {
		return ES_4;
	} 
}