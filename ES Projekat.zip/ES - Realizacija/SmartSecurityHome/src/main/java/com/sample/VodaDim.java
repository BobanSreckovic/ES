package com.sample;

public class VodaDim {
	
	// Promenljive unutar klase VodaDim
	private int senzorVoda;
	private int senzorDim;
	private String ES_2;
	
	// Setovanje ocitavanja senzora za detekciju vode
	public void setSenzorVoda(String senzorVoda) {
		if(senzorVoda.equals("Ima")) {
			this.senzorVoda = 1;
		}else {
			this.senzorVoda = 0;
		}
	}
	
	// Setovanje ocitavanja senzora za detekciju dima
	public void setSenzorDim(String senzorDim) {
		if(senzorDim.equals("Ima")) {
				this.senzorDim = 1;
			}else {
				this.senzorDim = 0;
			}
	}
	
	// Setovanje stanja ES_2
	public void setES_2() {
		if(senzorVoda == 0 && senzorDim == 0) {
			ES_2 = "Ni�ta";
		}else {
			ES_2 = "Slu�ba";
		}
		
	}
	
	// Getovanje stanja ES_2
	public String getES_2() {
		return ES_2;
	} 
}