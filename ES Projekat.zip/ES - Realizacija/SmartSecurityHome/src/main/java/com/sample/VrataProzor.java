package com.sample;

public class VrataProzor {
	
	// Promenljive unutar klase VrataProzor
	private int citacKartice;
	private int senzorPolozajaVrata;
	private int senzorProzora;
	private String ES_3;
	
	// Setovanje ocitavanja validnosti kartice
	public void setCitacKartice(String citacKartice) {
		if(citacKartice.equals("Validna")) {
			this.citacKartice = 1;
		}else {
			this.citacKartice = 0;
		}
	}

	// Setovanje ocitavanja senzora polo�aja vrata
	public void setSenzorPolozajaVrata(String senzorPolozajaVrata) {
		if(senzorPolozajaVrata.equals("Otvorena")) {
				this.senzorPolozajaVrata = 1;
			}else {
				this.senzorPolozajaVrata = 0;
			}
	}

	// Setovanje ocitavanja senzora za detekciju lomljenja stakla
	public void setSenzorProzora(String senzorProzora) {
		if(senzorProzora.equals("Aktiviran")) {
				this.senzorProzora = 1;
			}else {
				this.senzorProzora = 0;
			}
	}
	
	// Setovanje stanja ES_3
	public void setES_3() {
		if(citacKartice == 1 && senzorPolozajaVrata == 1 && senzorProzora == 0) {
			ES_3 = "Ni�ta";
		}else if((citacKartice == 1 || citacKartice == 0) && senzorPolozajaVrata == 0 && senzorProzora == 0) {
			ES_3 = "Slu�ba";
		}else{
			ES_3 = "Security";
		}
		
	}
	
	// Getovanje stanja ES_3
	public String getES_3() {
		return ES_3;
	} 
}