package com.sample;

public class Temp {
	
	// Promenljive unutar klase Temp
	private double senzorTemp;
	private String ES_1;
	
	// Setovanje ocitavanja senzora temperature
	public void setSenzorTemp(double senzorTemp) {
		this.senzorTemp = senzorTemp;
	}
	
	// Setovanje stanja ES_1
	public void setES_1() {
		if(senzorTemp >= 19.0 && senzorTemp <= 22.0){
			ES_1 = "Normalna";
			}else if(senzorTemp > 22.0){
				ES_1 = "Visoka";
			}else {
				ES_1 = "Niska";
				}
		
	}
	
	// Getovanje stanja ES_1
	public String getES_1() {
		return ES_1;
	}
}