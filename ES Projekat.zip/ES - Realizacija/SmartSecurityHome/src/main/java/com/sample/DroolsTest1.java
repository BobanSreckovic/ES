package com.sample;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;


public class DroolsTest1 {
	
	// Promenljiva koja sadr�i poruku preporucene akcije
	String poruka;
	
	
	// Setovanje poruke
	public void setPoruka(String poruka) {
		this.poruka = poruka;
	}
	
	
	// Getovanje poruke
	public void getPoruka() {
		System.out.println(poruka);
	}
	
    public static final void main(String[] args) {
        try {
	        KieServices ks = KieServices.Factory.get();
    	    KieContainer kContainer = ks.getKieClasspathContainer();
        	KieSession kSession = kContainer.newKieSession("ksession-rules");
        	
        	// Objekat klase DroolsTest (test) - za set/get poruke
        	DroolsTest test = new DroolsTest();
        	
        	
        	// Instanciranje objekta klase Temp
        	Temp t = new Temp();
        	
        	// Ocitavanje senzora (podataka)
        	// Ulazni parametar je ocitavanje sa senzora temperature
        	// Ulazni tip podatka/ocitavanja senzora je DOUBLE vrednost
        	t.setSenzorTemp(43.0);
        	
        	
        	// Instanciranje objekta klase VodaDim i setovanje vrednosti
        	VodaDim vd = new VodaDim();
        	
        	// Ocitavanje senzora (podataka)
        	// Ulazni parametri su ocitavanja senzora za detekciju vode i dima
        	// Ulazni tip podataka/ocitavanja senzora su STRING vrednosti
        	// Senzor za detekciju vode: Ima - Nema
        	vd.setSenzorVoda("Nema");
        	// Senzor za detekciju dima: Ima - Nema
        	vd.setSenzorDim("Nema");
        	
        	
        	// Instanciranje objekta klase VrataProzor i setovanje vrednosti
        	VrataProzor vp = new VrataProzor();
        	
        	// Ocitavanje validnosti kartice i senzora (podataka) 
        	// Ulazni parametri su ocitavanje validnosti kartice, senzora polo�aja vrata kao i senzor za detekciju lomljenja stakla
        	// Ulazni tip podataka/ocitavanja su STRING vrednosti
        	// Validnost kartice: Validna - Nije Validna
        	vp.setCitacKartice("Validna");
        	// Senzor polo�aja vrata: Otvorena - Zatvorena
        	vp.setSenzorPolozajaVrata("Otvorena");
        	// Senzor za detekciju lomljenja stakla: Aktiviran - Nije aktiviran
        	vp.setSenzorProzora("Nije Aktiviran");
        	
        	
        	// Instanciranje objekta klase Gas i setovanje vrednosti
        	Gas g = new Gas();
        	
        	// Ocitavanje senzora (podataka)
        	// Ulazni parametri su ocitavanja senzora za detekciju gasova
        	// Ulazni tip podataka/ocitavanja je DOUBLE vrednost (procenat koncentracije/prisustva gasa)
        	// Senzor za detekciju gasa - TNG (Tecni naftni gas)
        	g.setSenzorTNG(3.0);
        	// Senzor za detekciju gasa - CO (Ugljen monoksid)
        	g.setSenzorCO(2.5);
        	// Senzor za detekciju gasa - CH4 (Metan)
        	g.setSenzorCH4(2.6);
        	// Senzor za detekciju gasa - C3H8 (Propan)
        	g.setSenzorC3H8(3.4);
        	
        	
        	// Setovanje stanja ekspertskih sistema
        	
        	// Setovanje ES_1
        	// Moguca stanja: Niska - Normalna - Visoka
        	t.setES_1();
        	
        	// Setovanje ES_2
        	// Moguca stanja: Ni�ta - Slu�ba
        	vd.setES_2();
        	
        	// Setovanje ES_3
        	// Moguca stanja: Ni�ta - Slu�ba - Security
        	vp.setES_3();
        	
        	// Setovanje ES_4
        	// Moguca stanja: Ni�ta - Provetri - Slu�ba
        	g.setES_4();

        	
        	// Insertovanje objekata
        	// Objekat klase Temp
            kSession.insert(t);
            // Objekat klase VodaDim
            kSession.insert(vd);
            // Objekat klase VrataProzor
            kSession.insert(vp);
            // Objekat klase Gas
            kSession.insert(g);
            // Objekat klase DroolsTest
            kSession.insert(test);
            
            
            // Inicijalizacija pravila
            kSession.fireAllRules();
            
            
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
